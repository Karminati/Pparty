export class Avaliacao {
    idAvaliacao: number;
    quantAvaliacao: number;
    idUsuarioa: number;
    tbFesta_idFesta: number;

    constructor()
    {
        this.idAvaliacao = 0;
        this.quantAvaliacao = 0;
        this.idUsuarioa = 0;
        this.tbFesta_idFesta = 0;
    }

}
