import { FotoFesta } from './foto-festa';

describe('FotoFesta', () => {
  it('should create an instance', () => {
    expect(new FotoFesta()).toBeTruthy();
  });
});
