import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buscar-festa',
  templateUrl: './buscar-festa.page.html',
  styleUrls: ['./buscar-festa.page.scss'],
})
export class BuscarFestaPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
