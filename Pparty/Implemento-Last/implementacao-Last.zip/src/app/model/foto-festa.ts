export class FotoFesta {
    idFoto: number;
    url: string;
    fkFotoFesta: number;

    constructor()
    {
        this.idFoto = 0;
        this.url = "";
        this.fkFotoFesta = 0;
    }
}
