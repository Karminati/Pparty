export class Comentario {
    idComentario: number;
    coment: string;
    idAvaliacaoc: number;

    constructor(){
        this.idComentario = 0;
        this.coment = "";
        this.idAvaliacaoc = 0;
    }
}
