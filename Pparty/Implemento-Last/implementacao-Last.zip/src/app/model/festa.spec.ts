import { Festa } from './festa';

describe('Festa', () => {
  it('should create an instance', () => {
    expect(new Festa()).toBeTruthy();
  });
});
