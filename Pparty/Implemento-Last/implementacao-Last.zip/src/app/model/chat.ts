
export class Chat {
      idChat: number;
      idUsuario1: number;
      idUsuario2: number;

    constructor()
    {
        this.idChat = 0;
        this.idUsuario1 = 0;
        this.idUsuario2 = 0;

    }
}
