import { Avaliacao } from './avaliacao';

describe('Avaliacao', () => {
  it('should create an instance', () => {
    expect(new Avaliacao()).toBeTruthy();
  });
});
